import scipy.io as scio
import numpy as np

# YALE = 'Yale'
# UMIST = 'UMIST'
# ORL = 'ORL'
# COIL20 = 'COIL20'
# YALEB_SDSIFT = 'YaleB_DSIFT'
# JAFFE = 'JAFFE'
# MNIST_DSIFT = 'mnist_DSIFT'
# PALM = 'Palm'
# USPS = 'USPSdata_20_uni'
# TOY_THREE_RINGS = 'three_rings'
# MNIST_TEST = 'mnist_test'
# YEAST = 'yeast_uni'
# SEGMENT = 'segment_uni'
# NEWS = '20news_uni'
# WEBK = 'WebKB_wisconsin_uni'
# TEXT = 'text1_uni'
# GLASS = 'glass_uni'
# ISOLET = 'Isolet'
# CORA = 'cora'


def load_Xs_1():
    path = 'data/Xs_1.mat'
    data = scio.loadmat(path)
    X = data['Xs']
    X = X.astype(np.float32)
    X /= np.max(X)
    return X

def load_Xs_2():
    path = 'data/Xs_2.mat'
    data = scio.loadmat(path)
    labels = data['Ys']
    labels = np.reshape(labels, (labels.shape[0],))
    X = data['Xs']
    X = X.astype(np.float32)
    X /= np.max(X)
    return X, labels

def load_Xs_3():
    path = 'data/Xs_3.mat'
    data = scio.loadmat(path)
    labels = data['Ys']
    labels = np.reshape(labels, (labels.shape[0],))
    X = data['Xs']
    X = X.astype(np.float32)
    X /= np.max(X)
    return X, labels

def load_Xs_4():
    path = 'data/Xs_4.mat'
    data = scio.loadmat(path)
    labels = data['Ys']
    labels = np.reshape(labels, (labels.shape[0],))
    X = data['Xs']
    X = X.astype(np.float32)
    X /= np.max(X)
    return X, labels


def load_Xt_1():
    path = 'data/Xt_1.mat'
    data = scio.loadmat(path)
    labels = data['Yt']
    labels = np.reshape(labels, (labels.shape[0],))
    X = data['Xt']
    X = X.astype(np.float32)
    X /= np.max(X)
    return X, labels

def load_Xt_2():
    path = 'data/Xt_2.mat'
    data = scio.loadmat(path)
    labels = data['Yt']
    labels = np.reshape(labels, (labels.shape[0],))
    X = data['Xt']
    X = X.astype(np.float32)
    X /= np.max(X)
    return X, labels

def load_Xt_3():
    path = 'data/Xt_3.mat'
    data = scio.loadmat(path)
    labels = data['Yt']
    labels = np.reshape(labels, (labels.shape[0],))
    X = data['Xt']
    X = X.astype(np.float32)
    X /= np.max(X)
    return X, labels

def load_Xt_4():
    path = 'data/Xt_4.mat'
    data = scio.loadmat(path)
    labels = data['Yt']
    labels = np.reshape(labels, (labels.shape[0],))
    X = data['Xt']
    X = X.astype(np.float32)
    X /= np.max(X)
    return X, labels





